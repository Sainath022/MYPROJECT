﻿namespace Admin_user_MS.Models
{
    public class Loginpg
    {

        public string user_name { get; set; }

        public string password { get; set; }
    }
}
